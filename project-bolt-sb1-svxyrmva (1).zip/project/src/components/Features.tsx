import { Monitor, AlignCenterVertical as Certificate, Headphones as HeadphonesIcon, Download, Calendar, MapPin, Clock, Award } from 'lucide-react';

export default function Features() {
  const features = [
    {
      icon: <Monitor className="w-12 h-12 text-blue-600" />,
      title: "تدريب حضوري تفاعلي",
      description: "تعلم في بيئة تفاعلية مع المدرب والزملاء مباشرة"
    },
    {
      icon: <Certificate className="w-12 h-12 text-green-600" />,
      title: "شهادة معتمدة",
      description: "احصل على شهادة معتمدة قابلة للتوثيق من الجهات المختصة"
    },
    {
      icon: <HeadphonesIcon className="w-12 h-12 text-purple-600" />,
      title: "دعم فني مستمر",
      description: "دعم فني متواصل حتى بعد انتهاء الدورة لمدة 6 أشهر"
    },
    {
      icon: <Download className="w-12 h-12 text-yellow-600" />,
      title: "مواد تدريبية شاملة",
      description: "كتب ومراجع وملفات تطبيقية لجميع دروس الدورة"
    },
    {
      icon: <Calendar className="w-12 h-12 text-red-600" />,
      title: "جدولة مرنة",
      description: "اختر الوقت المناسب لك من بين عدة خيارات أسبوعية"
    },
    {
      icon: <MapPin className="w-12 h-12 text-indigo-600" />,
      title: "موقع متميز",
      description: "قاعات تدريبية حديثة في قلب المدينة مع مواقف مجانية"
    }
  ];

  const schedule = [
    {
      icon: <Clock className="w-6 h-6 text-blue-600" />,
      title: "المواعيد المسائية",
      time: "6:00 - 9:00 مساءً",
      days: "الأحد - الثلاثاء - الخميس"
    },
    {
      icon: <Clock className="w-6 h-6 text-green-600" />,
      title: "المواعيد الصباحية",
      time: "9:00 - 12:00 ظهراً",
      days: "السبت - الاثنين - الأربعاء"
    },
    {
      icon: <Clock className="w-6 h-6 text-purple-600" />,
      title: "نهاية الأسبوع",
      time: "10:00 - 4:00 مساءً",
      days: "الجمعة - السبت"
    }
  ];

  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            مميزات الدورة التدريبية
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            نقدم لك تجربة تعليمية متكاملة مع أفضل المرافق والخدمات التدريبية
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="flex justify-center mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">
                {feature.title}
              </h3>
              <p className="text-gray-600 text-center leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <Award className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              المواعيد المتاحة
            </h3>
            <p className="text-gray-600">
              اختر الوقت الذي يناسب جدولك اليومي
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {schedule.map((item, index) => (
              <div 
                key={index}
                className="border-2 border-gray-200 rounded-xl p-6 hover:border-blue-500 transition-colors duration-300"
              >
                <div className="flex items-center justify-center mb-4">
                  {item.icon}
                </div>
                <h4 className="text-lg font-bold text-gray-900 mb-2 text-center">
                  {item.title}
                </h4>
                <p className="text-blue-600 font-semibold text-center mb-2">
                  {item.time}
                </p>
                <p className="text-gray-600 text-center text-sm">
                  {item.days}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}