import { Star, Quote } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      name: "أحمد محمد",
      role: "مهندس معماري",
      company: "شركة البناء المتطور",
      rating: 5,
      text: "دورة رائعة ومفيدة جداً. المدرب محترف والمنهج شامل. تعلمت كل ما أحتاجه للعمل بـ AutoCAD بشكل احترافي.",
      image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    },
    {
      name: "فاطمة العلي",
      role: "مهندسة مدني",
      company: "مكتب الهندسة الحديثة",
      rating: 5,
      text: "استفدت كثيراً من هذه الدورة. الآن أستطيع إنجاز مشاريعي بسرعة ودقة أكبر. أنصح بها بشدة لكل المهندسين.",
      image: "https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    },
    {
      name: "خالد السعيد",
      role: "مصمم داخلي",
      company: "استوديو التصميم الإبداعي",
      rating: 5,
      text: "المدرب ممتاز والمواد التدريبية شاملة. حصلت على وظيفة جديدة بعد شهر من انتهاء الدورة بفضل المهارات التي تعلمتها.",
      image: "https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    },
    {
      name: "نورا أحمد",
      role: "طالبة هندسة",
      company: "جامعة الملك سعود",
      rating: 5,
      text: "كطالبة هندسة، هذه الدورة ساعدتني كثيراً في مشاريع الجامعة. المنهج واضح والتطبيق العملي ممتاز.",
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    },
    {
      name: "محمد الغامدي",
      role: "مهندس ميكانيكي",
      company: "شركة الصناعات المتقدمة",
      rating: 5,
      text: "دورة احترافية بكل معنى الكلمة. تعلمت تقنيات متقدمة لم أكن أعرفها من قبل. الاستثمار في هذه الدورة كان قراراً صائباً.",
      image: "https://images.pexels.com/photos/2182975/pexels-photo-2182975.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    },
    {
      name: "سارة الحربي",
      role: "مهندسة كهربائية",
      company: "مؤسسة الطاقة المتجددة",
      rating: 5,
      text: "المدرب خبير في المجال والدعم الفني ممتاز. حتى بعد انتهاء الدورة، ما زلت أحصل على المساعدة عند الحاجة.",
      image: "https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            آراء المتدربين
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            اكتشف تجارب المتدربين السابقين وكيف غيرت هذه الدورة مسارهم المهني
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="flex items-center mb-4">
                <Quote className="w-8 h-8 text-blue-600 opacity-50" />
              </div>
              
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>

              <p className="text-gray-700 mb-6 leading-relaxed">
                "{testimonial.text}"
              </p>

              <div className="flex items-center">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover ml-4"
                />
                <div>
                  <h4 className="font-bold text-gray-900">
                    {testimonial.name}
                  </h4>
                  <p className="text-sm text-gray-600">
                    {testimonial.role}
                  </p>
                  <p className="text-xs text-blue-600">
                    {testimonial.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-blue-900 mb-4">
              انضم إلى +500 متدرب ناجح
            </h3>
            <p className="text-blue-700 mb-6">
              كن جزءاً من مجتمع المحترفين الذين طوروا مهاراتهم معنا
            </p>
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-300">
              ابدأ رحلتك الآن
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}