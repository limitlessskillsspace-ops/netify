import { CheckCircle, Target, BookOpen, Users } from 'lucide-react';

export default function About() {
  const objectives = [
    "إتقان واجهة AutoCAD وأدوات الرسم الأساسية",
    "تعلم تقنيات الرسم الهندسي والمعماري المتقدمة",
    "إنشاء وتعديل الكتل والرموز الهندسية",
    "استخدام أدوات القياس والأبعاد بدقة",
    "تطبيق معايير الرسم الهندسي الدولية",
    "إخراج الرسومات للطباعة بجودة احترافية"
  ];

  const features = [
    {
      icon: <BookOpen className="w-8 h-8 text-blue-600" />,
      title: "منهج شامل ومتدرج",
      description: "من الأساسيات إلى التقنيات المتقدمة"
    },
    {
      icon: <Users className="w-8 h-8 text-green-600" />,
      title: "تدريب عملي مكثف",
      description: "75% من الوقت مخصص للتطبيق العملي"
    },
    {
      icon: <Target className="w-8 h-8 text-yellow-600" />,
      title: "مشاريع حقيقية",
      description: "تطبيق على مشاريع من السوق الفعلي"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            عن دورة AutoCAD 2D
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            دورة تدريبية شاملة مصممة لتأهيلك للعمل في مجال التصميم الهندسي والمعماري 
            باستخدام أحدث تقنيات AutoCAD 2D
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
          <div className="text-right">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              أهداف الدورة
            </h3>
            <div className="space-y-4">
              {objectives.map((objective, index) => (
                <div key={index} className="flex items-start space-x-3 rtl:space-x-reverse">
                  <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                  <span className="text-gray-700 text-lg">{objective}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-yellow-50 p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              إحصائيات الدورة
            </h3>
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">60</div>
                <div className="text-gray-600">ساعة تدريبية</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">15</div>
                <div className="text-gray-600">مشروع عملي</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-600 mb-2">500+</div>
                <div className="text-gray-600">متدرب سابق</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">95%</div>
                <div className="text-gray-600">نسبة النجاح</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6 rounded-xl bg-gray-50 hover:bg-white hover:shadow-lg transition-all duration-300">
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">
                {feature.title}
              </h4>
              <p className="text-gray-600">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}