import { Check, Star, Zap } from 'lucide-react';

export default function Pricing() {
  const plans = [
    {
      name: "الباقة الأساسية",
      price: "120,000",
      originalPrice: "150,000",
      duration: "30 يوم",
      popular: false,
      features: [
        "60 ساعة تدريبية",
        "مواد تدريبية شاملة",
        "شهادة حضور",
        "دعم فني لمدة 3 أشهر",
        "10 مشاريع عملية",
        "وصول لمجموعة الخريجين"
      ]
    },
    {
      name: "الباقة المتقدمة",
      price: "180,000",
      originalPrice: "220,000",
      duration: "45 يوم",
      popular: true,
      features: [
        "كل مميزات الباقة الأساسية",
        "20 ساعة إضافية متقدمة",
        "شهادة معتمدة دولياً",
        "دعم فني لمدة 6 أشهر",
        "15 مشروع عملي متقدم",
        "ورشة عمل مجانية شهرياً",
        "استشارة مهنية مجانية",
        "أولوية في التوظيف"
      ]
    },
    {
      name: "الباقة الاحترافية",
      price: "250,000",
      originalPrice: "300,000",
      duration: "60 يوم",
      popular: false,
      features: [
        "كل مميزات الباقة المتقدمة",
        "تدريب فردي 10 ساعات",
        "شهادة احترافية معتمدة",
        "دعم فني مدى الحياة",
        "25 مشروع احترافي",
        "تدريب على AutoCAD 3D",
        "دورة مجانية سنوياً",
        "شراكة في المشاريع"
      ]
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            باقات التدريب
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            اختر الباقة التي تناسب احتياجاتك وميزانيتك
          </p>
          <div className="inline-flex items-center bg-green-100 text-green-800 px-6 py-3 rounded-full">
            <Zap className="w-5 h-5 ml-2" />
            عرض محدود: خصم 20% على جميع الباقات
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={`relative bg-white rounded-2xl shadow-xl p-8 transform transition-all duration-300 hover:scale-105 ${
                plan.popular 
                  ? 'border-4 border-blue-500 shadow-2xl' 
                  : 'border border-gray-200'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-blue-500 text-white px-6 py-2 rounded-full flex items-center">
                    <Star className="w-4 h-4 ml-1 fill-current" />
                    الأكثر طلباً
                  </div>
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {plan.name}
                </h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold text-blue-600">
                    {plan.price}
                  </span>
                  <span className="text-gray-600 mr-2">دج</span>
                  <div className="text-sm text-gray-500 line-through">
                    {plan.originalPrice} دج
                  </div>
                </div>
                <div className="text-gray-600">
                  مدة التدريب: {plan.duration}
                </div>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-1 ml-3" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <button 
                className={`w-full py-4 px-6 rounded-lg font-semibold text-lg transition-all duration-300 ${
                  plan.popular
                    ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                }`}
              >
                {plan.popular ? 'اختر هذه الباقة' : 'تفاصيل أكثر'}
              </button>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 max-w-2xl mx-auto">
            <h4 className="text-xl font-bold text-yellow-800 mb-2">
              ضمان استرداد المال
            </h4>
            <p className="text-yellow-700">
              إذا لم تكن راضياً عن الدورة خلال أول 7 أيام، نضمن لك استرداد كامل للمبلغ
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}