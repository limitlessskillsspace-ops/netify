import { User, Mail, Phone, MapPin, CreditCard, Calendar, CheckCircle, AlertCircle } from 'lucide-react';
import { useState } from 'react';

export default function Registration() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    package: 'advanced',
    paymentMethod: 'bank',
    experience: 'beginner',
    motivation: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const packages = [
    {
      id: 'basic',
      name: 'الباقة الأساسية',
      price: '120,000',
      originalPrice: '150,000',
      features: ['60 ساعة تدريبية', 'شهادة حضور', 'دعم 3 أشهر']
    },
    {
      id: 'advanced',
      name: 'الباقة المتقدمة',
      price: '180,000',
      originalPrice: '220,000',
      features: ['80 ساعة تدريبية', 'شهادة معتمدة', 'دعم 6 أشهر'],
      popular: true
    },
    {
      id: 'professional',
      name: 'الباقة الاحترافية',
      price: '250,000',
      originalPrice: '300,000',
      features: ['100 ساعة تدريبية', 'شهادة احترافية', 'دعم مدى الحياة']
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setShowSuccess(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setShowSuccess(false);
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        address: '',
        package: 'advanced',
        paymentMethod: 'bank',
        experience: 'beginner',
        motivation: ''
      });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (showSuccess) {
    return (
      <section id="registration" className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-white rounded-2xl shadow-2xl p-12">
              <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                تم التسجيل بنجاح! 🎉
              </h2>
              <p className="text-xl text-gray-600 mb-6">
                شكراً لك على التسجيل في دورة AutoCAD 2D
              </p>
              <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
                <p className="text-green-800 font-medium">
                  سيتم التواصل معك خلال 24 ساعة لتأكيد التسجيل وإرسال تفاصيل الدفع
                </p>
              </div>
              <div className="text-gray-600">
                <p>📧 تحقق من بريدك الإلكتروني للحصول على تفاصيل إضافية</p>
                <p>📱 أو تواصل معنا على: +966 50 123 4567</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="registration" className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            سجل الآن في الدورة
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
            احجز مقعدك في دورة AutoCAD 2D واحصل على خصم 20% للتسجيل المبكر
          </p>
          <div className="inline-flex items-center bg-red-100 text-red-800 px-6 py-3 rounded-full">
            <AlertCircle className="w-5 h-5 ml-2" />
            العرض ينتهي خلال 7 أيام - المقاعد محدودة!
          </div>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Package Selection */}
            <div className="lg:col-span-1">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">اختر الباقة</h3>
              <div className="space-y-4">
                {packages.map((pkg) => (
                  <div
                    key={pkg.id}
                    className={`relative border-2 rounded-xl p-4 cursor-pointer transition-all duration-300 ${
                      formData.package === pkg.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                    onClick={() => setFormData({ ...formData, package: pkg.id })}
                  >
                    {pkg.popular && (
                      <div className="absolute -top-2 right-4 bg-blue-500 text-white px-3 py-1 rounded-full text-sm">
                        الأكثر طلباً
                      </div>
                    )}
                    <div className="flex items-center mb-2">
                      <input
                        type="radio"
                        name="package"
                        value={pkg.id}
                        checked={formData.package === pkg.id}
                        onChange={handleChange}
                        className="ml-3 text-blue-600"
                      />
                      <div>
                        <h4 className="font-bold text-gray-900">{pkg.name}</h4>
                        <div className="flex items-center space-x-2 rtl:space-x-reverse">
                          <span className="text-2xl font-bold text-blue-600">{pkg.price} دج</span>
                          <span className="text-sm text-gray-500 line-through">{pkg.originalPrice} دج</span>
                        </div>
                      </div>
                    </div>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {pkg.features.map((feature, index) => (
                        <li key={index} className="flex items-center">
                          <CheckCircle className="w-4 h-4 text-green-500 ml-2" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>

            {/* Registration Form */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">معلومات التسجيل</h3>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <User className="w-4 h-4 inline ml-1" />
                        الاسم الكامل *
                      </label>
                      <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                        placeholder="أدخل اسمك الكامل"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Mail className="w-4 h-4 inline ml-1" />
                        البريد الإلكتروني *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                        placeholder="example@email.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Phone className="w-4 h-4 inline ml-1" />
                        رقم الهاتف *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                        placeholder="+966 5X XXX XXXX"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <MapPin className="w-4 h-4 inline ml-1" />
                        المدينة *
                      </label>
                      <input
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                        placeholder="الرياض، جدة، الدمام..."
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        مستوى الخبرة
                      </label>
                      <select
                        name="experience"
                        value={formData.experience}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                      >
                        <option value="beginner">مبتدئ</option>
                        <option value="intermediate">متوسط</option>
                        <option value="advanced">متقدم</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <CreditCard className="w-4 h-4 inline ml-1" />
                        طريقة الدفع المفضلة
                      </label>
                      <select
                        name="paymentMethod"
                        value={formData.paymentMethod}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                      >
                        <option value="bank">تحويل بنكي</option>
                        <option value="cash">نقداً</option>
                        <option value="installment">تقسيط</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      لماذا تريد تعلم AutoCAD؟ (اختياري)
                    </label>
                    <textarea
                      name="motivation"
                      value={formData.motivation}
                      onChange={handleChange}
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 resize-none"
                      placeholder="أخبرنا عن أهدافك من تعلم AutoCAD..."
                    ></textarea>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h4 className="font-bold text-yellow-800 mb-2">ملاحظات مهمة:</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• سيتم التواصل معك خلال 24 ساعة لتأكيد التسجيل</li>
                      <li>• يمكن الدفع نقداً أو بالتحويل البنكي</li>
                      <li>• ضمان استرداد المال خلال أول 7 أيام</li>
                      <li>• المقاعد محدودة - 20 متدرب فقط لكل دفعة</li>
                    </ul>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`w-full py-4 px-6 rounded-lg font-bold text-lg transition-all duration-300 transform hover:scale-105 ${
                      isSubmitting
                        ? 'bg-gray-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl'
                    }`}
                  >
                    {isSubmitting ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white ml-2"></div>
                        جاري التسجيل...
                      </div>
                    ) : (
                      <div className="flex items-center justify-center">
                        <Calendar className="w-6 h-6 ml-2" />
                        سجل الآن - احجز مقعدك
                      </div>
                    )}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}