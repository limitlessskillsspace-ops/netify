import { Menu, X, Phone, Mail } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <img 
              src="/src/assets/5861597458516265604.jpg" 
              alt="LIMITLESS Skills" 
              className="h-12 w-auto"
            />
          </div>

          <nav className="hidden md:flex items-center space-x-8 rtl:space-x-reverse">
            <a href="#home" className="text-gray-700 hover:text-blue-600 transition-colors">الرئيسية</a>
            <a href="#about" className="text-gray-700 hover:text-blue-600 transition-colors">عن الدورة</a>
            <a href="#features" className="text-gray-700 hover:text-blue-600 transition-colors">المميزات</a>
            <a href="#registration" className="text-gray-700 hover:text-blue-600 transition-colors">التسجيل</a>
            <a href="#pricing" className="text-gray-700 hover:text-blue-600 transition-colors">الأسعار</a>
            <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors">تواصل معنا</a>
          </nav>

          <div className="hidden md:flex items-center space-x-4 rtl:space-x-reverse">
            <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600">
              <Phone className="w-4 h-4" />
              <span>+213 55 123 4567</span>
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600">
              <Mail className="w-4 h-4" />
              <span>info@limitlessskills.com</span>
            </div>
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-4">
              <a href="#home" className="text-gray-700 hover:text-blue-600 transition-colors">الرئيسية</a>
              <a href="#about" className="text-gray-700 hover:text-blue-600 transition-colors">عن الدورة</a>
              <a href="#features" className="text-gray-700 hover:text-blue-600 transition-colors">المميزات</a>
              <a href="#registration" className="text-gray-700 hover:text-blue-600 transition-colors">التسجيل</a>
              <a href="#pricing" className="text-gray-700 hover:text-blue-600 transition-colors">الأسعار</a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors">تواصل معنا</a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}