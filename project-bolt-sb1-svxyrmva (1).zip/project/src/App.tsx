import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Features from './components/Features';
import Registration from './components/Registration';
import Pricing from './components/Pricing';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';

function App() {
  return (
    <div className="min-h-screen" dir="rtl">
      <Header />
      <Hero />
      <About />
      <Features />
      <Registration />
      <Pricing />
      <Testimonials />
      <Contact />
    </div>
  );
}

export default App;